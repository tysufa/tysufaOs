package com.fs.starfarer.api.campaign.econ;

import java.util.List;

public interface MarketDemandDataAPI {
	List<MarketDemandAPI> getDemandList();
}
