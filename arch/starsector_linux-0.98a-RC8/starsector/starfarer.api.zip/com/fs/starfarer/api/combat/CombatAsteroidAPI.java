package com.fs.starfarer.api.combat;

import com.fs.starfarer.api.graphics.SpriteAPI;

public interface CombatAsteroidAPI extends CombatEntityAPI {
	SpriteAPI getSpriteAPI();
}
