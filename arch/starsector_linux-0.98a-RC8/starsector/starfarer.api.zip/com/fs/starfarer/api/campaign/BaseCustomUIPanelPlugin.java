package com.fs.starfarer.api.campaign;

import java.util.List;

import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.ui.PositionAPI;

public class BaseCustomUIPanelPlugin implements CustomUIPanelPlugin {

	public void positionChanged(PositionAPI position) {
		
	}

	public void renderBelow(float alphaMult) {
		
	}

	public void render(float alphaMult) {
		
	}

	public void advance(float amount) {
		
	}

	public void processInput(List<InputEventAPI> events) {
		
	}

	public void buttonPressed(Object buttonId) {
		
	}

}
