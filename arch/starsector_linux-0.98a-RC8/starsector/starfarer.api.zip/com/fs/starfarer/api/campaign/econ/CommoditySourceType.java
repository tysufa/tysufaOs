/**
 * 
 */
package com.fs.starfarer.api.campaign.econ;


public enum CommoditySourceType {
	GLOBAL,
	IN_FACTION,
	LOCAL,
	NONE,
}