package com.fs.starfarer.api.campaign.econ;



public interface SubmarketSpecAPI {
	String getId();
	String getName();
	String getDesc();
	String getIcon();
	String getFactionId();
}
