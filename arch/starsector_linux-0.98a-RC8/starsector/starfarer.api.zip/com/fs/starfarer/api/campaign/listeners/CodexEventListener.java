package com.fs.starfarer.api.campaign.listeners;

public interface CodexEventListener {
	void reportAboutToOpenCodex();
	void reportClosedCodex();
}
