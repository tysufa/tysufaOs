package com.fs.starfarer.api.campaign;

public interface RenderingAffectedByAbyssalDepth {
	float getAlphaMultFromAbyssalDepth();
}
