package com.fs.starfarer.api.combat;

public interface WeaponEffectPluginWithInit {
	void init(WeaponAPI weapon);
	
}
