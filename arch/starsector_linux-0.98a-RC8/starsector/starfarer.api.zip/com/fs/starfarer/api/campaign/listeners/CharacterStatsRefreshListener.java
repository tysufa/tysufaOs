package com.fs.starfarer.api.campaign.listeners;

public interface CharacterStatsRefreshListener {
	void reportAboutToRefreshCharacterStatEffects();
	void reportRefreshedCharacterStatEffects();
}
