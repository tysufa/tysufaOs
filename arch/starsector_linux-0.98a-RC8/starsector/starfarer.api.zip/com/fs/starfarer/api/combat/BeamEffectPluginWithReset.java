package com.fs.starfarer.api.combat;

public interface BeamEffectPluginWithReset extends BeamEffectPlugin {
	void reset();
}
