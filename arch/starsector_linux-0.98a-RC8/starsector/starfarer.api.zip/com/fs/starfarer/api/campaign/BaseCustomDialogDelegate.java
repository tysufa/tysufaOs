package com.fs.starfarer.api.campaign;

import com.fs.starfarer.api.ui.CustomPanelAPI;

public class BaseCustomDialogDelegate implements CustomDialogDelegate {

	public void createCustomDialog(CustomPanelAPI panel, CustomDialogCallback callback) {
		// TODO Auto-generated method stub
		
	}

	public boolean hasCancelButton() {
		// TODO Auto-generated method stub
		return false;
	}

	public String getConfirmText() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getCancelText() {
		// TODO Auto-generated method stub
		return null;
	}

	public void customDialogConfirm() {
		// TODO Auto-generated method stub
		
	}

	public void customDialogCancel() {
		// TODO Auto-generated method stub
		
	}

	public CustomUIPanelPlugin getCustomPanelPlugin() {
		// TODO Auto-generated method stub
		return null;
	}

}
